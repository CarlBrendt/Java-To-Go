package main

import (
	"encoding/json"
	"time"
)

type ExchangeService struct{}

type MailFilter struct{}

type WorkerState struct{}

type JsonNodeType string

type BlobStorageServiceClient struct{}

type MessageSource struct{}
type JsonValidator interface{}
type BlobStorage interface{}

type ExceptionHolder struct {
    Exception error `json:"exception"`
}  

type ReqScriptExecutionContext struct {
    Vars json.RawMessage        `json:"vars"`
    Wf   ReqScriptWorkflowView   `json:"wf"`
} 
type ReqScriptWorkflowView struct {
    BusinessKey   string                         `json:"businessKey"`
    Secrets       map[string]string              `json:"secrets"`
    InitVariables map[string]json.RawMessage     `json:"initVariables"`
} 

type ResResolvePlaceholdersExecutionResult struct {
    ResultNode json.RawMessage `json:"resultNode"`
}

type ReqFilterOutput struct {
    Filter map[string]string   `json:"filter"`
    Ctx    ScriptExecutionContext `json:"ctx"`
    Output json.RawMessage      `json:"output"`
}

type ValidationServiceImpl struct {
    ScriptValidationService StarterScriptValidationService `json:"scriptValidationService"`
    ObjectMapper            interface{}                     `json:"objectMapper"`
    ErrorCompiler           ErrorCompiler                   `json:"errorCompiler"`
    ScriptExecutorService   ScriptExecutorService           `json:"scriptExecutorService"`
}

type MailWorkerLocalManager struct{}

type Internationalizer struct{}

type VariablesJsonSchema struct {
    Title      string                     `json:"title"`
    Type       json.RawMessage            `json:"type"`
    StringFormat string                   `json:"stringFormat"`
    Properties map[string]Property        `json:"properties" validate:"dive"`
    Definitions map[string]Property       `json:"definitions" validate:"dive"`
    Required   []string                   `json:"required"`
    Enums      []string                   `json:"-"`
    Items      []Property                 `json:"items"`
    Ref        string                     `json:"-"`
    MinLength  *int                       `json:"-"`
    Src        json.RawMessage            `json:"-"`
}  // ← ДОБАВИТЬ

type Property struct {
    Type          json.RawMessage          `json:"type"`
    StringFormat  string                   `json:"stringFormat"`
    Description   string                   `json:"description"`
    Ref           string                   `json:"$ref"`
    Items         []Property               `json:"items" validate:"dive"`
    Required      []string                 `json:"required"`
    Enums         []string                 `json:"enum"`
    MinLength     *int                     `json:"minLength"`
    Properties    map[string]Property      `json:"properties" validate:"dive"`
}  

type InternationalizerImpl struct {
    MessageSource MessageSource `json:"messageSource"`
} 

type CustomSSLSocketFactory struct {
    Factory interface{} `json:"factory"`
}  

type JsonExample struct {
    Definitions          map[string]VariablesJsonSchema `json:"definitions"`
    Om                   interface{}                    `json:"om"`
    Generated            json.RawMessage                `json:"generated"`
    StringFormatExamples map[string]string             `json:"stringFormatExamples"`
}

type MailConsumerManagerState struct {
    Workers []WorkerState `json:"workers"`
}

type Variables struct {
    OBJECT_MAPPER interface{}               `json:"OBJECT_MAPPER"`
    Vars          map[string]json.RawMessage `json:"vars"`
}

type StarterScriptValidationServiceImpl struct {
    ObjectMapper          interface{}          `json:"objectMapper"`
    ErrorCompiler         ErrorCompiler        `json:"errorCompiler"`
    DefaultValidationSchema VariablesJsonSchema `json:"defaultValidationSchema"`
    VariableValidator     JsonValidator        `json:"variableValidator"`
    ScriptExecutorService ScriptExecutorService `json:"scriptExecutorService"`
} 

type VariableValidatorImpl struct {
    Om interface{} `json:"om"`
}  

type RemoteBlobStorage struct {
    BlobServiceClient BlobStorageServiceClient `json:"blobServiceClient"`
    OM                interface{}               `json:"OM"`
}  

type ResSavedBlob struct {
    ID string `json:"id"`
}  

type BlobRef struct {
    ID        string   `json:"id"`
    NodeType  JsonNodeType `json:"nodeType"`
    LeftAnchor string      `json:"leftAnchor"`
} 

type BlobSaveOptions struct {
    FileName            string    `json:"fileName"`
    RunId               string    `json:"runId"`
    BusinessKey         string    `json:"businessKey"`
    WorkflowDefinitionId string `json:"workflowDefinitionId"`
    ExpirationDate      time.Time `json:"expirationDate"`
}  

type ExchangeMessageProcessor struct {
    Worker                     Worker                     `json:"worker"`
    Props                      EngineConfigurationProperties `json:"props"`
    StarterScriptValidationService StarterScriptValidationService `json:"starterScriptValidationService"`
    WorkflowEngine             WorkflowEngine             `json:"workflowEngine"`
    BlobStorage                BlobStorage                `json:"blobStorage"`
    OM                         interface{}                `json:"OM"`
    ExceptionHolder            ExceptionHolder            `json:"exceptionHolder"`
}  

type ExchangeMessageSource struct {
    Worker          Worker          `json:"worker"`
    ExchangeService ExchangeService `json:"exchangeService"`
    MaxFetchSize    int             `json:"maxFetchSize"`
    ExceptionHolder ExceptionHolder `json:"exceptionHolder"`
} 

type SearchTermStrategyImpl struct {
    MailFilter MailFilter `json:"mailFilter"`
}  

type ImapMessageProcessor struct {
    Worker                     Worker                     `json:"worker"`
    Props                      EngineConfigurationProperties `json:"props"`
    StarterScriptValidationService StarterScriptValidationService `json:"starterScriptValidationService"`
    WorkflowEngine             WorkflowEngine             `json:"workflowEngine"`
    BlobStorage                BlobStorage                `json:"blobStorage"`
    OM                         interface{}                `json:"OM"`
    ExceptionHolder            ExceptionHolder            `json:"exceptionHolder"`
}  