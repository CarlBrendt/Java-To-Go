package main

import (
	"encoding/json"
	"regexp"
	"time"
	"crypto/cipher"
)

type ResCommonError struct {
    Timestamp time.Time `json:"timestamp"`
    Status    int       `json:"status"`
    Error     string    `json:"error"`
    Path      string    `json:"path"`
}

type Starter struct {
    Id                         string          `json:"id"`
    Name                       string             `json:"name"`
    Type                       string             `json:"type"`
    TenantId                   string             `json:"tenantId"`
    Description                string             `json:"description"`
    WorkflowDefinitionToStartId string          `json:"workflowDefinitionToStartId"`
    WorkflowInputValidateSchema json.RawMessage    `json:"workflowInputValidateSchema"`
    MailConsumer               MailStarterDetails `json:"mailConsumer"`
}

type MailStarterDetails struct {
    ConnectionDef MailConnection `json:"connectionDef"`
    MailFilter    MailFilter     `json:"mailFilter"`
    PollConfig    MailPollConfig `json:"pollConfig"`
    OutputTemplate json.RawMessage `json:"outputTemplate"`
}

type ResReplacedStarter struct {
    OldStarter ResShortStarter `json:"oldStarter"`
    NewStarter ResShortStarter `json:"newStarter"`
}

type ResShortStarter struct {
    StarterId string `json:"starterId"`
    WorkflowId string `json:"workflowId"`
}

type ResRestTemplateErrorDescription struct {
    Errors []*ResErrorDescription `json:"errors"`
}

type ResErrorLocation struct {
    FieldPath string `json:"fieldPath"`
}

type ResErrorContext struct {
    RejectedValue interface{} `json:"rejectedValue"`
}

type ResScriptErrorContext struct {
    VariableContext   json.RawMessage   `json:"variableContext"`
    Wf                ScriptWorkflowView `json:"wf"`
    RejectedScript    string            `json:"rejectedScript"`
    SystemMessage     string            `json:"systemMessage"`
    UnknownVariables []string          `json:"unknownVariables"`
}

type ResInputValidationContext struct {
    InputValidateSchema json.RawMessage   `json:"inputValidateSchema"`
    ValidationTarget    json.RawMessage   `json:"validationTarget"`
    PropertyViolations  []PropertyViolation `json:"propertyViolations"`
}

type PropertyViolation struct {
    PropertyRootPath string                 `json:"propertyRootPath"`
    ConstraintPath   string                 `json:"constraintPath"`
    PropertyName     string                 `json:"propertyName"`
    SystemMessage    string                 `json:"systemMessage"`
    ConstraintType   string                 `json:"constraintType"`
    Details          map[string]interface{} `json:"details"`
}

type ResErrorDescription struct {
    Code                    string                 `json:"code"`
    Level                   string                 `json:"level"`
    Message                 string                 `json:"message"`
    SystemMessage           string                 `json:"systemMessage"`
    SolvingAdviceMessage   string                 `json:"solvingAdviceMessage"`
    SolvingAdviceUrl        string                 `json:"solvingAdviceUrl"`
    Location                *ResErrorLocation      `json:"location"`
    Context                 *ResErrorContext       `json:"context"`
    ScriptContext           *ResScriptErrorContext `json:"scriptContext"`
    InputValidationContext  *ResInputValidationContext `json:"inputValidationContext"`
    Cause                   []*ResErrorDescription `json:"cause"`
}

type ReqMailStarterConfig struct {}

type WorkerIdentity struct {
    WorkerId   string `json:"workerId"`
    ExecutorId string `json:"executorId"`}

type ReqCompatibilityStarter struct {
    Consumer                     ReqMailConsumerForInternal `json:"consumer"`
    WorkflowInputValidateSchema json.RawMessage            `json:"workflowInputValidateSchema"`}

type ResStarterSearch struct {
    Total    int64                     `json:"total"`
    Starters []ResStarterShortListValue `json:"starters"`}

type WorkerError struct {
    WorkerId    string `json:"workerId"`
    ExecutorId  string `json:"executorId"`
    ErrorMessage string    `json:"errorMessage"`
    StackTrace   string    `json:"stackTrace"`}

type ResStarterShortListValue struct {
    Id                         string `json:"id"`
    Name                       string    `json:"name"`
    TenantId                   string    `json:"tenantId"`
    Description                string    `json:"description"`
    DesiredStatus              string    `json:"desiredStatus"`
    ActualStatus               string    `json:"actualStatus"`
    CreateTime                 string    `json:"createTime"`
    WorkflowDefinitionToStartId string `json:"workflowDefinitionToStartId"`}

type ResValidationResult struct {
    Errors []*ResErrorDescription `json:"errors"`}

type Scheduler struct {
    Workers MailWorkerLocalManager `json:"workers"`}

type MailListenerContainerWrapper struct {
    WorkerId        string        `json:"workerId"`
    IntegrationFlow IntegrationFlow  `json:"integrationFlow"`
    ExceptionHolder ExceptionHolder  `json:"exceptionHolder"`
    ExchangeService ExchangeService  `json:"exchangeService"`}

type FetchedVaultPropertiesResolver struct {
    LEFT_ANCHOR          string          `json:"LEFT_ANCHOR"`
    RGHT_ANCHOR          string          `json:"RGHT_ANCHOR"`
    LEFT_ANCHOR_PATTERN  *regexp.Regexp  `json:"LEFT_ANCHOR_PATTERN"`
    RIGHT_ANCHOR_PATTERN *regexp.Regexp  `json:"RIGHT_ANCHOR_PATTERN"`}

type VaultEntry struct {
    Raw   string `json:"raw"`
    Path  string `json:"path"`
    Field string `json:"field"`}

type SimpleCrypt struct {
    RAW        []byte       `json:"RAW"`
    SALT       []byte       `json:"SALT"`
    EnCrypter  cipher.Block `json:"enCrypter"`
    DeCrypter  cipher.Block `json:"deCrypter"`}

type Utils struct {}

type Interval struct {
    Start Area `json:"start"`
    End   Area `json:"end"`}

type Area struct {
    Start int  `json:"start"`
    End   int  `json:"end"`
    Left  bool `json:"left"`}

type ValidationService struct {
    ScriptValidationService StarterScriptValidationService `json:"scriptValidationService"`
    ErrorCompiler           ErrorCompiler                  `json:"errorCompiler"`
    ScriptExecutorService   ScriptExecutorService          `json:"scriptExecutorService"`
    ObjectMapper            ObjectMapper                   `json:"objectMapper"`
}

type MailWorkerLocalManagerImpl struct {
    ConsumerManager MailReceiverManager          `json:"consumerManager"`
    Props           EngineConfigurationProperties `json:"props"`
    EngineClient    WorkflowEngineClient          `json:"engineClient"`}

type MailReceiverManagerImpl struct {
    AllWorkers               map[string]MailListenerContainerWrapper `json:"allWorkers"`
    Mapper                   DtoMapper                                 `json:"mapper"`
    ListenerConfig           DynamicMailListener                        `json:"listenerConfig"`
    VaultPropertiesResolver  FetchedVaultPropertiesResolver             `json:"vaultPropertiesResolver"`
    FlowContext              IntegrationFlowContext                     `json:"flowContext"`}
