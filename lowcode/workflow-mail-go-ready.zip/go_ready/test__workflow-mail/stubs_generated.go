package main


// Auto-generated stubs for missing types.
// TODO: Replace with real implementations.

// TODO: Define ApplyPlaneVaultSecrets properly
type ApplyPlaneVaultSecrets struct{}

// TODO: Define CloseBrokenConsumers properly
type CloseBrokenConsumers struct{}

// TODO: Define CompileExecutionContext properly
type CompileExecutionContext struct{}

// TODO: Define CompileScriptContext properly
type CompileScriptContext struct{}

// TODO: Define CreateExampleForSchema properly
type CreateExampleForSchema struct{}

// TODO: Define DeserializeBlob properly
type DeserializeBlob struct{}

// TODO: Define ErrorDecoder properly
type ErrorDecoder struct{}

// TODO: Define ExecuteScript properly
type ExecuteScript struct{}

// TODO: Define Filter properly
type Filter struct{}

// TODO: Define Find properly
type Find struct{}

// TODO: Define FindJson properly
type FindJson struct{}

// TODO: Define GetHealthyConsumers properly
type GetHealthyConsumers struct{}

// TODO: Define GetWorkerCount properly
type GetWorkerCount struct{}

// TODO: Define HttpStatus properly
type HttpStatus struct{}

// TODO: Define InjectActivityArgsToContext properly
type InjectActivityArgsToContext struct{}

// TODO: Define IntegrationFlow properly
type IntegrationFlow struct{}

// TODO: Define IntegrationFlowContext properly
type IntegrationFlowContext struct{}

// TODO: Define IsExecutable properly
type IsExecutable struct{}

// TODO: Define Parse properly
type Parse struct{}

// TODO: Define ResolvePlaceholders properly
type ResolvePlaceholders struct{}

// TODO: Define Save properly
type Save struct{}

// TODO: Define ScriptExecutorClient properly
type ScriptExecutorClient struct{}

// TODO: Define StartFlow properly
type StartFlow struct{}

// TODO: Define StartWorker properly
type StartWorker struct{}

// TODO: Define StopProcessByWorkerId properly
type StopProcessByWorkerId struct{}

// TODO: Define StopStolenLocalWorkers properly
type StopStolenLocalWorkers struct{}

// TODO: Define ToVariablesJsonSchema properly
type ToVariablesJsonSchema struct{}

// TODO: Define TransformMailOutput properly
type TransformMailOutput struct{}

// TODO: Define Valid properly
type Valid struct{}

// TODO: Define Validate properly
type Validate struct{}

// TODO: Define ValidateJson properly
type ValidateJson struct{}

// TODO: Define ValidateOutputTemplateValueReplacement properly
type ValidateOutputTemplateValueReplacement struct{}

// TODO: Define ValidateStarterCompatibility properly
type ValidateStarterCompatibility struct{}

// TODO: Define ValidateVariables properly
type ValidateVariables struct{}