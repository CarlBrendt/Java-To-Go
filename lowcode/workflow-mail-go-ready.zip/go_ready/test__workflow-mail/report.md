# 🚀 Java → Go Migration Report

**Generated:** 2026-04-22 16:22:09  
**Package:** `ru.mts.workflowmail`

## 📊 Executive Summary

| Metric | Value |
|--------|-------|
| Status | **⚠️ PARTIAL** |
| Java Controllers | 2 |
| Java Services | 7 |
| Java DTOs | 173 |
| Feign Clients | 4 |
| Total Endpoints | 3 |
| Endpoints Migrated | 3 |
| Coverage | **100.0%** |
| Go Files Generated | 18 |
| Verification | ✅ PASSED |
| Build | ❌ FAILED |
| Startup | ⚠️ Not verified |
| Stub Types | 34 |
| Manual Items | 18 |

## 🔧 Build & Startup

| Check | Result |
|-------|--------|
| Compilation (`go build ./...`) | ❌ FAILED |
| Startup (port 8080) | ⚠️ Not verified |
| Health Check (`/health`) | ⚠️ Not verified |
| Auto-fixes applied | 1 |
| Remaining errors | 1 |

### Auto-fixes Applied

- ✅ Generated go.mod

### Remaining Errors

> See `BUILD_REPORT.md` for detailed fix instructions.

1. `missing import path`

## 🔄 Automatic Code Consolidation

**60 automatic fixes** applied to generated code:

- Package unification: **20** fixes
- Duplicate types removed: **20** fixes
- Import cleanup: **14** fixes
- Other cleanup: **4** fixes
- Base type aliases: **1** fixes
- Stubs generated: **1** fixes

<details>
<summary>Show all consolidation fixes</summary>

- [consolidate] Added 1 base type aliases
- [consolidate] models_1.go: package models → main
- [consolidate] models_2.go: package models → main
- [consolidate] models_3.go: package models → main
- [consolidate] models_4.go: package models → main
- [consolidate] models_5.go: package models → main
- [consolidate] models_6.go: package models → main
- [consolidate] remote_workflow_engine.go: package services → main
- [consolidate] mail_receiver_manager.go: package services → main
- [consolidate] script_executor_service.go: package services → main
- [consolidate] validation_service.go: package services → main
- [consolidate] starter_script_validation_service.go: package services → main
- [consolidate] variable_validator.go: package services → main
- [consolidate] remote_blob_storage.go: package services → main
- [consolidate] models_2.go: removed duplicate type DtoMapper (kept in models_1.go)
- [consolidate] models_6.go: removed duplicate type ErrorDescription (kept in models_1.go)
- [consolidate] models_6.go: removed duplicate type ErrorMessageArgs (kept in models_1.go)
- [consolidate] models_5.go: removed duplicate type StarterScriptValidationService (kept in models_1.go)
- [consolidate] starter_script_validation_service.go: removed duplicate type StarterScriptValidationService (kept in models_1.go)
- [consolidate] models_5.go: removed duplicate type ErrorCompiler (kept in models_1.go)
- [consolidate] models_5.go: removed duplicate type ScriptExecutorService (kept in models_1.go)
- [consolidate] script_executor_service.go: removed duplicate type ScriptExecutorService (kept in models_1.go)
- [consolidate] models_2.go: removed duplicate type ScriptExecutionContext (kept in models_1.go)
- [consolidate] models_5.go: removed duplicate type ScriptExecutionContext (kept in models_1.go)
- [consolidate] remote_workflow_engine.go: removed duplicate type RemoteWorkflowEngine (kept in models_1.go)
- [consolidate] models_5.go: removed duplicate type WorkflowEngine (kept in models_1.go)
- [consolidate] models_5.go: removed duplicate type EngineConfigurationProperties (kept in models_1.go)
- [consolidate] models_5.go: removed duplicate type Worker (kept in models_2.go)
- [consolidate] validation_service.go: removed duplicate type ValidationService (kept in models_3.go)
- [consolidate] models_5.go: removed duplicate type WikiErrorPageProvider (kept in models_4.go)
- [consolidate] mail_receiver_manager.go: removed duplicate type MailReceiverManager (kept in models_4.go)
- [consolidate] models_6.go: removed duplicate type MailFilter (kept in models_5.go)
- [consolidate] models_6.go: removed duplicate type WorkerState (kept in models_5.go)
- [consolidate] remote_blob_storage.go: removed duplicate type RemoteBlobStorage (kept in models_5.go)
- [consolidate] remote_workflow_engine.go: removed package prefixes
- [consolidate] mail_receiver_manager.go: removed package prefixes
- [consolidate] script_executor_service.go: removed package prefixes
- [consolidate] validation_service.go: removed package prefixes
- [consolidate] starter_script_validation_service.go: removed package prefixes
- [consolidate] variable_validator.go: removed package prefixes
- [consolidate] remote_blob_storage.go: removed package prefixes
- [consolidate] Generated stubs for 34 missing types: ApplyPlaneVaultSecrets, CloseBrokenConsumers, CompileExecutionContext, CompileScriptContext, CreateExampleForSchema, DeserializeBlob, ErrorDecoder, ExecuteScript, Filter, Find
- [consolidate] models_1.go: rebuilt imports
- [consolidate] models_2.go: rebuilt imports
- [consolidate] models_3.go: rebuilt imports
- [consolidate] models_4.go: rebuilt imports
- [consolidate] models_5.go: rebuilt imports
- [consolidate] models_6.go: rebuilt imports
- [consolidate] remote_workflow_engine.go: rebuilt imports
- [consolidate] mail_receiver_manager.go: rebuilt imports
- [consolidate] script_executor_service.go: rebuilt imports
- [consolidate] validation_service.go: rebuilt imports
- [consolidate] starter_script_validation_service.go: rebuilt imports
- [consolidate] variable_validator.go: rebuilt imports
- [consolidate] remote_blob_storage.go: rebuilt imports
- [consolidate] stubs_generated.go: rebuilt imports
- models_2.go: cleaned Java array syntax
- models_3.go: cleaned Java array syntax
- models_5.go: cleaned Java array syntax
- mail_receiver_manager.go: cleaned Java array syntax

</details>

## ✅ Migrated Endpoints

| Method | Path | Handler | Java Class |
|--------|------|---------|------------|
| `GET` | `/` | `redirect` | `SwaggerRediraction` |
| `POST` | `/api/v1/consumer/validate` | `validateStarterConfig` | `MailValidationApiImpl` |
| `POST` | `/api/v1/consumer/workflow-compatibility/validate` | `validateStarterCompatibility` | `MailValidationApiImpl` |

## 📦 Generated Files

| File | Size | Purpose | Needs Review |
|------|------|---------|-------------|
| `models_1.go` | 8314 chars | Data models | ✅ Ready |
| `models_2.go` | 4703 chars | Data models | ✅ Ready |
| `models_3.go` | 6814 chars | Data models | ✅ Ready |
| `models_4.go` | 5287 chars | Data models | ✅ Ready |
| `models_5.go` | 6240 chars | Data models | ✅ Ready |
| `models_6.go` | 3086 chars | Data models | ✅ Ready |
| `remote_workflow_engine.go` | 445 chars | Other | ⚠️ Has TODOs |
| `mail_receiver_manager.go` | 2154 chars | Other | ⚠️ Has TODOs |
| `script_executor_service.go` | 1897 chars | Business logic | ⚠️ Has TODOs |
| `validation_service.go` | 1428 chars | Business logic | ⚠️ Has TODOs |
| `starter_script_validation_service.go` | 2547 chars | Business logic | ⚠️ Has TODOs |
| `variable_validator.go` | 413 chars | Other | ⚠️ Has TODOs |
| `remote_blob_storage.go` | 1095 chars | Other | ⚠️ Has TODOs |
| `router.go` | 858 chars | Router | ✅ Ready |
| `main.go` | 849 chars | Entry point | ✅ Ready |
| `handlers.go` | 1406 chars | HTTP Handlers | ⚠️ Has TODOs |
| `types_common.go` | 305 chars | Data models | ✅ Ready |
| `stubs_generated.go` | 2615 chars | Stubs (need implementation) | 🔴 All stubs |

## 🧩 Stub Types (need implementation)

**34 types** and **0 constructors** are empty stubs in `stubs_generated.go`.

These compile but have no real logic. Replace with actual implementations:

- `ApplyPlaneVaultSecrets`, `CloseBrokenConsumers`, `CompileExecutionContext`, `CompileScriptContext`
- `CreateExampleForSchema`, `DeserializeBlob`, `ErrorDecoder`, `ExecuteScript`
- `Filter`, `Find`, `FindJson`, `GetHealthyConsumers`
- `GetWorkerCount`, `HttpStatus`, `InjectActivityArgsToContext`, `IntegrationFlow`
- `IntegrationFlowContext`, `IsExecutable`, `Parse`, `ResolvePlaceholders`
- `Save`, `ScriptExecutorClient`, `StartFlow`, `StartWorker`
- `StopProcessByWorkerId`, `StopStolenLocalWorkers`, `ToVariablesJsonSchema`, `TransformMailOutput`
- `Valid`, `Validate`, `ValidateJson`, `ValidateOutputTemplateValueReplacement`
- `ValidateStarterCompatibility`, `ValidateVariables`

## ⏭️ Not Migrated (intentionally)

These Java components were **intentionally skipped** and need manual implementation:

- Feign Clients (4 шт: Application, WorkflowEngineClient, ScriptExecutorClient, BlobStorageServiceClient) — нужна реализация HTTP-клиентов (net/http или go-resty)
- Exception Handlers (1 шт: GlobalControllerExceptionHandler) — реализовать как Gin middleware

## ⚠️ Action Items for Engineer

**18 items** need attention:

### 🟡 Important (functionality)

- 🟡 `stubs_generated.go`: 34 типов-заглушек и 0 конструкторов — заменить реальными реализациями
- 🟡 `handlers.go`: 3 обработчиков с заглушками — реализовать бизнес-логику
- 🟡 Сервисы: 17 TODO-комментариев в бизнес-логике

### 🔵 Normal

- 🔵 Проверить синтаксис в `models_1.go` — несовпадение скобок ({ = 39, } = 17).
- 🔵 Проверить синтаксис в `models_2.go` — несовпадение скобок ({ = 31, } = 10).
- 🔵 Проверить синтаксис в `models_3.go` — несовпадение скобок ({ = 32, } = 5).
- 🔵 Проверить синтаксис в `models_4.go` — несовпадение скобок ({ = 30, } = 1).
- 🔵 Проверить синтаксис в `models_5.go` — несовпадение скобок ({ = 41, } = 18).
- 🔵 Проверить синтаксис в `models_6.go` — несовпадение скобок ({ = 30, } = 12).
- 🔵 Проверить синтаксис в `mail_receiver_manager.go` — несовпадение скобок ({ = 11, } = 3).
- 🔵 Проверить синтаксис в `script_executor_service.go` — несовпадение скобок ({ = 9, } = 2).
- 🔵 Проверить синтаксис в `validation_service.go` — несовпадение скобок ({ = 7, } = 2).
- 🔵 Проверить синтаксис в `starter_script_validation_service.go` — несовпадение скобок ({ = 9, } = 1).
- 🔵 Проверить синтаксис в `variable_validator.go` — несовпадение скобок ({ = 4, } = 1).
- 🔵 Проверить синтаксис в `remote_blob_storage.go` — несовпадение скобок ({ = 6, } = 1).
- 🔵 Проверить синтаксис в `handlers.go` — несовпадение скобок ({ = 8, } = 4).

### ⚪ Info (skipped components)

- ⚪ Feign Clients (4 шт: Application, WorkflowEngineClient, ScriptExecutorClient, BlobStorageServiceClient) — нужна реализация HTTP-клиентов (net/http или go-resty)
- ⚪ Exception Handlers (1 шт: GlobalControllerExceptionHandler) — реализовать как Gin middleware

## 🔄 Library Mapping

| Java / Spring | Go Equivalent |
|--------------|---------------|
| Spring Boot (@Controller, @Service) | Go Structs + Methods |
| Spring MVC (@GetMapping, @PostMapping) | Gin Router |
| Jackson (JSON) | encoding/json + struct tags |
| Lombok (@Data, @Builder) | Go Structs (explicit fields) |
| Hibernate / JPA | GORM / sqlx (не используется) |
| Spring Security | Gin Middleware |
| SLF4J / Logback | log/slog (stdlib) |
| Spring @Transactional | Manual DB transactions |

## 🤖 AI Usage Disclosure

This migration uses AI (LLM) for specific stages. Here's exactly where:

| Stage | Method | AI Used | What to Review |
|-------|--------|---------|---------------|
| 1. Java Parsing | JavaParser AST | ❌ No | — |
| 2. Migration Plan | LLM | ✅ Yes | Review plan for completeness |
| 3. Data Layer (models) | LLM | ✅ Yes | Verify struct fields and types |
| 4. Business Logic | LLM | ✅ Yes | **Review all TODO comments** |
| 5. API Layer (handlers) | Template | ❌ No | Add business logic to handlers |
| 6. Consolidation | Deterministic | ❌ No | — |
| 7. Verification | Deterministic | ❌ No | — |
| 8. Build Check | `go build` | ❌ No | — |
| 9. Reporting | Template | ❌ No | — |

> **Key insight:** Stages 3 and 4 use AI. All generated structs and service methods should be reviewed by an engineer. Stages 5-9 are fully deterministic and produce compilable code.

## 🛠️ Next Steps

### Immediate (get it running)

1. `cd output/go_project`
2. `go mod tidy && go build ./...`
3. `./main` — verify health check at `http://localhost:8080/health`

### Short-term (make it work)

4. Review and fix `stubs_generated.go` — replace empty structs with real types
5. Implement business logic in `handlers.go` (search for `// TODO`)
6. Implement service methods (search for `// implementation`)
7. Configure database connection (environment variables)

### Medium-term (make it production-ready)

8. Write unit tests for handlers and services
9. Write integration tests — compare Java vs Go responses
10. Add proper logging (zerolog/slog)
11. Add metrics (Prometheus)
12. Deploy with `Dockerfile` (included)

## 📋 Migration Plan

<details>
<summary>Click to expand</summary>

# Migration Plan – Java Spring Boot → Go (Gin)

> **Scope** – The source project lives in package `ru.mts.workflowmail`.  
> The goal is to re‑implement the public API (Swagger UI redirection, validation endpoints) and the core business services (workflow start, mail‑consumer management, script execution, blob storage, etc.) in a pure Go code‑base while preserving behaviour, error handling, and observability.

---

## 1. Go Project Structure  

| Directory | Purpose | Typical Files |
|-----------|---------|---------------|
| `go.mod` | Module definition (e.g. `module github.com/yourorg/workflowmail`) | – |
| `cmd/` | Application entry‑point (`main.go`) and CLI helpers | `main.go` |
| `internal/` | Private implementation (not exported to other modules) |
| `internal/app/` | High‑level wiring (router, server start, DI container) | `router.go`, `server.go`, `wire.go` |
| `internal/handlers/` | HTTP handlers (Gin) – one file per controller group | `swagger_redirect.go`, `mail_validation.go` |
| `internal/models/` | DTOs / request‑/response structs (generated from Java DTOs) | `starter.go`, `validation.go`, `error.go`, … |
| `internal/services/` | Business‑logic services (equivalent to Spring `@Service`) | `remote_workflow_engine.go`, `mail_receiver_manager.go`, `script_executor.go`, `validation_service.go`, … |
| `internal/repository/` | Persistence layer (GORM / sqlx) – entities, queries | `worker_repo.go`, `starter_repo.go`, `blob_repo.go` |
| `internal/middleware/` | Gin middleware (security, logging, tracing, panic recovery) | `auth.go`, `tracing.go`, `logger.go` |
| `internal/config/` | Configuration structs (mirrors `EngineConfigurationProperties`) | `config.go`, `load.go` |
| `internal/util/` | Helper functions (date parsing, crypto, json utils) | `date.go`, `crypto.go`, `json.go` |
| `internal/validation/` | Wrapper around `go-playground/validator` and custom validators (cron, duration, UUID, JSON‑Schema) | `validator.go`, `custom_rules.go` |
| `internal/clients/` | HTTP / gRPC clients for external services (workflow engine, script executor, blob storage) | `workflow_engine_client.go`, `script_executor_client.go`, `blob_storage_client.go` |
| `internal/observability/` | OpenTelemetry, metrics, health checks | `otel.go`, `metrics.go` |
| `test/` | Integration / contract tests (uses `httptest` and the real services) | `router_test.go`, `validation_test.go` |
| `scripts/` | Code‑generation helpers (e.g. JSON‑Schema → Go structs) | `gen_models.sh` |

**Package naming convention** – keep the same logical grouping as the Java package hierarchy, but all packages are under `internal/` to enforce encapsulation.

---

## 2. Endpoint Mapping  

| Java Controller / Method | HTTP Method | Path | Go Handler (file) | Gin Group |
|--------------------------|-------------|------|-------------------|-----------|
| `SwaggerRediraction.redirect()` | GET | `/` | `func RedirectSwagger(c *gin.Context)` | `public` |
| `MailValidationApiImpl.validateStarterConfig()` | POST | `/api/v1/consumer/validate` | `func ValidateStarterConfig(c *gin.Context)` | `apiV1` |
| `MailValidationApiImpl.validateStarterCompatibility()` | POST | `/api/v1/consumer/workflow-compatibility/validate` | `func ValidateStarterCompatibility(c *gin.Context)` | `apiV1` |
| (Exception handlers – not exposed as routes) | – | – | Global error‑handling middleware `RecoverAndTranslate` | – |

**Router wiring (example)**  

```go
func RegisterRoutes(r *gin.Engine, svc *services.ServiceContainer) {
    // public (no auth)
    public := r.Group("/")
    {
        public.GET("/", handlers.RedirectSwagger)
    }

    // API v1 – secured (auth middleware applied)
    apiV1 := r.Group("/api/v1")
    apiV1.Use(middleware.AuthRequired())
    {
        apiV1.POST("/consumer/validate", handlers.ValidateStarterConfig(svc.ValidationService))
        apiV1.POST("/consumer/workflow-compatibility/validate",
            handlers.ValidateStarterCompatibility(svc.ValidationService))
    }

    // global error handling
    r.Use(middleware.RecoverAndTranslate())
}
```

*Each handler receives a *service* (or a subset of services) via constructor injection – see **Section 3**.*

---

## 3. Library Mapping  

| Spring / Java Concept | Go Equivalent | Remarks |
|-----------------------|---------------|---------|
| **Spring Web (Spring MVC)** | **Gin** (`github.com/gin-gonic/gin`) | Fast, minimal, supports groups, middleware, JSON binding. |
| **Spring DI (`@Autowired`, `@Component`)** | **Constructor injection** – services are structs with dependencies passed in the constructor (or via a simple manual DI container). | Example: `type ValidationService struct { validator *validation.Validator; scriptSvc ScriptExecutorService }` |
| **JPA / Hibernate** | **GORM** (`gorm.io/gorm`) **or** **sqlx** (`github.com/jmoiron/sqlx`) | Choose GORM for quick mapping of entities (`Worker`, `Starter`, etc.). For read‑only queries, sqlx can be used for performance. |
| **Jackson (`ObjectMapper`)** | **encoding/json** (standard) + **github.com/json-iterator/go** (optional for speed) | Use struct tags `json:"fieldName"`; custom (de)serializers via `MarshalJSON`/`UnmarshalJSON`. |
| **Bean Validation (`javax.validation`)** | **go-playground/validator** (`github.com/go-playground/validator/v10`) | Custom validation functions for `cron`, `duration`, `UUID`, `json-schema`. |
| **Spring Security** | **Gin middleware** – JWT / API‑key validation, role checks. | Implement `AuthRequired()` that extracts a token, validates against the same auth server used by the Java app. |
| **Logging (`slf4j`, `logback`)** | **zerolog** (`github.com/rs/zerolog`) **or** **slog** (Go 1.21) | Structured JSON logs, same fields (`request_id`, `tenant_id`, `error_code`). |
| **OpenTelemetry (`spring-boot-starter-actuator`, `opentelemetry`)** | **go.opentelemetry.io/otel** + **otelgin** middleware | Export traces to the same collector endpoint (`opentelemetryTraceExporterEndpoint`). |
| **Spring MVC ExceptionHandler** | **Gin Recovery + custom error translator** | Middleware that catches panics and custom error types (`ClientError`, `ConstraintViolationError`) and writes `ResCommonErrorWithDescriptions`. |
| **Spring `@Value` / `@ConfigurationProperties`** | **Viper** (`github.com/spf13/viper`) or **envconfig** | Load `EngineConfigurationProperties` into a Go struct (`config.Config`). |
| **Spring `@Scheduled` / `TaskScheduler`** | **robfig/cron** (`github.com/robfig/cron/v3`) or **time.Ticker** | Used for the mail‑worker scheduler (`Scheduler`). |
| **Spring `@Async`** | **goroutine** + **worker pool** (e.g. `ants` library) | For background processing (script execution, blob storage). |

---

## 4. Data Layer Strategy  

### 4.1 General Mapping Rules  

| Java Type | Go Type | Notes |
|-----------|---------|-------|
| `String` | `string` | – |
| `int` / `Integer` | `int` (or `int32` if needed) | Primitive int is non‑null; use pointer `*int` for optional fields. |
| `long` / `Long` | `int64` | Use `*int64` for nullable. |
| `boolean` / `Boolean` | `bool` | Use `*bool` for optional. |
| `UUID` | `github.com/google/uuid.UUID` | Marshal/unmarshal as string (`json:"id"`). |
| `OffsetDateTime` / `ZonedDateTime` | `time.Time` (with `time.RFC3339Nano`) | Use `*time.Time` for nullable. |
| `Duration` | `time.Duration` | JSON representation as string (`"PT5M"` → parse with `time.ParseDuration` after conversion). |
| `JsonNode` | `json.RawMessage` or `map[string]any` | For generic JSON payloads use `json.RawMessage`. |
| `List<T>` | `[]T` | Slice; empty slice for `null` → `omitempty`. |
| `Set<T>` | `map[T]struct{}` or `[]T` (if order not required) | Usually `[]T` is sufficient. |
| `Map<K,V>` | `map[K]V` | Use appropriate key type (`string`). |
| `Optional<T>` | `*T` | Nil means absent. |
| `Enum` (String constants) | `string` with const block | Define Go `type X string` and const values. |
| `@Getter/@Setter` | Exported fields (`FieldName`) | No need for explicit getters/setters unless custom logic required. |
| `@JsonProperty("$ref")` | `json:"$ref"` | Use back‑ticks for struct tags. |
| `@JsonIgnore` | `json:"-"` | Skip during (de)serialization. |
| `@Valid` | `validate:"dive"` (go‑playground) | Nested validation. |
| `@NotNull`, `@NotEmpty`, `@NotBlank` | `validate:"required"` (or custom) | Add to struct tags. |
| `@Pattern(regexp=…)` | `validate:"regexp=…" ` | Use custom validator if needed. |
| `@Size(min=…, max=…)` | `validate:"min=…,max=…" ` | Same. |

### 4.2 Example DTO Conversion  

```go
// Java: ReqStartWorkflow
type ReqStartWorkflow struct {
    WorkflowRef        ReqRef               `json:"workflowRef" validate:"required,dive"`
    WorkflowStartConfig ReqWorkflowStartConfig `json:"workflowStartConfig" validate:"required,dive"`
}

// Java: ReqWorkflowStartConfig
type ReqWorkflowStartConfig struct {
    BusinessKey      string          `json:"businessKey,omitempty"`
    Variables        json.RawMessage `json:"variables,omitempty"` // raw JSON
    TaskTimeout      *time.Duration  `json:"taskTimeout,omitempty" validate:"omitempty,gt=0"`
    RunTimeout       *time.Duration  `json:"runTimeout,omitempty"  validate:"omitempty,gt=0"`
    ExecutionTimeout *time.Duration  `json:"executionTimeout,omitempty" validate:"omitempty,gt=0"`
}

// Java: ReqRef
type ReqRef struct {
    ID       uuid.UUID `json:"id" validate:"required,uuid"`
    Name     string    `json:"name,omitempty"`
    TenantID string    `json:"tenantId,omitempty"`
}
```

*All DTOs are placed under `internal/models/`.  Generation scripts can read the Java source (or the JSON you provided) and emit Go structs with the appropriate tags.*

### 4.3 Persistence Entities  

*Only a subset of DTOs are persisted (e.g., `Worker`, `Starter`, `BlobRef`).*  
For each entity:

```go
type Worker struct {
    ID               uuid.UUID      `gorm:"type:uuid;primaryKey" json:"id"`
    CreateTime       time.Time      `gorm:"autoCreateTime" json:"createTime"`
    ChangeTime       time.Time      `gorm:"autoUpdateTime" json:"changeTime"`
    ExecutorID       uuid.UUID      `gorm:"type:uuid;index" json:"executorId"`
    LockedUntilTime  *time.Time     `json:"lockedUntilTime,omitempty"`
    RetryCount       *int           `json:"retryCount,omitempty"`
    Status           string         `json:"status"`
    ErrorMessage     *string        `json:"errorMessage,omitempty"`
    ErrorStackTrace  *string        `json:"errorStackTrace,omitempty"`
    StarterID        uuid.UUID      `gorm:"type:uuid" json:"starterId"`
    Starter          Starter        `gorm:"foreignKey:StarterID" json:"starter"`
}
```

*GORM tags replace JPA annotations (`@Entity`, `@Column`, `@ManyToOne`).*

---

## 5. Business Logic Strategy  

| Service (Java) | Go Service (file) | Migration Complexity | Comments |
|----------------|-------------------|----------------------|----------|
| `RemoteWorkflowEngine` (client wrapper) | `remote_workflow_engine.go` | **Simple** | Thin HTTP client; map method signatures, reuse generated DTO structs. |
| `MailReceiverManagerImpl` (worker lifecycle) | `mail_receiver_manager.go` | **Medium** | Needs conversion of `IntegrationFlow` (Spring Integration) to Go goroutine workers + channel pipelines.  Core logic (start/stop, apply vault secrets) can be ported, but the Spring Integration DSL must be rewritten. |
| `ScriptExecutorServiceImpl` (script execution, placeholder resolution) | `script_executor.go` | **Complex** | In Java it delegates to a remote script‑executor service; the Go version must marshal the same request structs, handle retries, and translate error payloads (`ClientError`, `ErrorDescription`).  Also includes custom validation of scripts (SPEL/JP) – may need a Go expression engine or keep remote call. |
| `ValidationServiceImpl` (JSON‑Schema validation, variable validation) | `validation_service.go` | **Medium** | Uses `JsonValidator` and custom `VariableValidatorImpl`.  In Go we can use `github.com/qri-io/jsonschema` for schema validation and reuse the same custom rules.  The “parse” and “valid” helpers are straightforward. |
| `StarterScriptValidationServiceImpl` (script compilation, output‑template validation) | `starter_script_validation.go` | **Complex** | Involves script compilation, placeholder resolution, and JSON‑Schema generation.  Must either call the same remote script‑executor or embed a lightweight engine (e.g., `otto` for JS, or keep JP/SPEL via remote service).  The schema‑to‑Go conversion can be automated, but the validation of output‑template placeholders is custom. |
| `VariableValidatorImpl` (validate variables against schema) | `variable_validator.go` | **Simple** | Direct call to JSON‑Schema validator. |
| `RemoteBlobStorage` (Azure Blob client) | `blob_storage_client.go` | **Simple** | Azure SDK for Go (`github.com/Azure/azure-sdk-for-go/sdk/storage/azblob`).  Map `save`, `find`, `findJson`, `deserializeBlob`. |
| `ExchangeMessageProcessor` / `ImapMessageProcessor` (message handling) | `exchange_message_processor.go`, `imap_message_processor.go` | **Complex** | These classes depend on Spring Integration, `IntegrationFlow`, and `MessageChannel`.  In Go we will replace them with a pipeline of goroutines + channels, using the `mail` package (`github.com/emersion/go-imap`) for IMAP, and custom structs for exchange messages. |
| `DynamicMailListener` (dynamic listener creation) | `dynamic_mail_listener.go` | **Complex** | Must translate the dynamic creation of `IntegrationFlow` into runtime‑generated goroutine workers that poll the mailbox according to the configuration stored in DB. |
| `Scheduler` (periodic start of workers) | `scheduler.go` | **Simple** | Use `cron.New()` to schedule `StartWorker` calls. |
| `ErrorCompiler`, `ErrorMessagePouch`, `ErrorLocation`, etc. | `error_helpers.go` | **Simple** | Pure data transformation; copy logic, adapt to Go error types. |
| `SecurityConfiguration`, `SwaggerConfig`, `ObservationConfiguration` | `middleware/*` and `observability/*` | **Simple** | Translate to Gin middleware and OpenTelemetry setup. |

**Key take‑aways**

* **Simple** – thin wrappers around HTTP clients, DTO conversion, or pure data helpers.  
* **Medium** – business logic that is mostly procedural but depends on Spring‑specific APIs (e.g., IntegrationFlow).  
* **Complex** – any component that uses Spring Integration, custom script engines, or heavy reflection/annotation processing. These will need a redesign in Go.

---

## 6. Manual Refactoring Steps  

1. **Spring Integration → Go Pipelines**  
   * Replace `IntegrationFlow`, `MessageChannel`, `MessageHandler` with explicit goroutine workers and Go channels.  
   * Ensure back‑pressure handling (buffered channels, context cancellation).  

2. **Script Execution (JP / SPEL)**  
   * Decide whether to keep the remote script‑executor service (simpler) or embed a Go engine.  
   * If embedding, map JP/SPEL to an equivalent (e.g., `otto` for JavaScript, `govaluate` for expressions).  

3. **Vault Secrets Resolution**  
   * The Java `FetchedVaultPropertiesResolver` parses `${...}` placeholders.  
   * Implement a Go version that uses regex to replace placeholders from a secret store (e.g., HashiCorp Vault client).  

4. **Custom Validation Rules**  
   * `CronValidator`, `ValidDuration`, `ValidUUID`, `ValidJSONSchema`, `ValidOutputTemplateValueReplacement` – write custom `validator.Func` implementations.  

5. **Error Mapping**  
   * Java `ClientError` contains `HttpStatus` and a list of `ClientErrorDescription`.  
   * In Go define a struct `ClientError` with `Status int` and `Errors []ErrorDescription`.  
   * Middleware must translate Go errors (`*ClientError`, `*ConstraintViolationError`) into the JSON shape expected by existing clients.  

6. **Configuration Loading**  
   * Java uses `@ConfigurationProperties`.  
   * In Go, load YAML/JSON/TOML via Viper, validate required fields, and expose a singleton `config.Config`.  

7. **Database Schema Migration**  
   * Export the current DB schema (PostgreSQL, etc.) and generate GORM models.  
   * Run migration scripts (e.g., using `golang-migrate/migrate`).  

8. **Logging Context Propagation**  
   * Preserve MDC (`Mapped Diagnostic Context`) values (e.g., request ID, tenant ID) across goroutine boundaries using `zerolog.Ctx` or `slog` with `context.Context`.  

9. **OpenTelemetry Context**  
   * Add `otelgin.Middleware` and propagate spans through background goroutines (`otel.Start`).  

10. **Testing of Edge Cases**  
    * The Java code contains many custom error codes (`Errors2`). Ensure the same codes are emitted in Go.  
    * Verify that the `ResCommonErrorWithDescriptions` format matches the contract exactly (field order, naming).  

11. **Swagger / OpenAPI Generation**  
    * Use `swaggo/swag` annotations in Go handlers to generate the same Swagger UI.  
    * Compare generated spec with the original Java `swagger.json` to guarantee compatibility.  

12. **Dependency Injection Container**  
    * If the project is large, consider using a lightweight DI library (e.g., `uber-go/dig`) to wire services automatically, mirroring Spring’s component scanning.  

13. **Thread‑Safety Review**  
    * Ensure all shared structures (e.g., `MailWorkerLocalManager.workers` map) are protected by mutexes or use `sync.Map`.  

14. **Graceful Shutdown**  
    * Implement signal handling (`os/signal`) to stop all workers, close DB connections, and flush logs – equivalent to Spring’s `DisposableBean`.  

---

## 7. Testing Strategy  

| Test Type | Scope | Tools / Approach |
|-----------|-------|------------------|
| **Unit Tests** | Individual services, validators, DTO (un)marshalling | `testing` + `github.com/stretchr/testify/assert` |
| **Integration Tests (HTTP)** | End‑to‑end request/response for each API endpoint, including error handling | `net/http/httptest`, `github.com/gin-gonic/gin` test mode, compare JSON payloads with Java reference fixtures. |
| **Contract Tests** | Verify that the OpenAPI spec produced by Go matches the original Java spec (paths, request/response schemas, error codes) | `swagger-cli validate`, `openapi-diff` or custom diff script. |
| **Database Tests** | Repository layer – CRUD operations, transaction boundaries | Use a Dockerized test DB (Postgres) with `testcontainers-go`. |
| **External Service Mocks** | Mock `WorkflowEngineClient`, `ScriptExecutorClient`, `BlobStorageClient` | `github.com/golang/mock` or hand‑written fakes that return deterministic JSON. |
| **Performance / Load Tests** | Simulate many concurrent mail workers, script executions | `k6` or `hey` against the Go server; compare latency with Java baseline. |
| **Security Tests** | JWT validation, role‑based access, input sanitisation | `github.com/securego/gosec` static analysis + runtime tests for auth middleware. |
| **Observability Tests** | Ensure traces and metrics are emitted | Use an in‑memory OTEL exporter (`go.opentelemetry.io/otel/sdk/trace/tracetest`) and assert span attributes. |
| **Chaos / Resilience Tests** | Simulate downstream failures (workflow engine, blob storage) and verify retry/back‑off logic | Use `github.com/avast/retry-go` in code; tests inject failures via mocks. |

**CI Pipeline** – Add stages:

1. `go vet` + `staticcheck` (code quality).  
2. Unit + integration tests (`go test ./... -cover`).  
3. OpenAPI diff against stored Java spec.  
4. Docker build & smoke test (`docker run` + health‑check).  

---

### TL;DR – What to Deliver  

* A **new Go module** with the layout described in Section 1.  
* Auto‑generated **model structs** (Section 4) from the JSON you supplied.  
* **Gin router** wiring matching every Java endpoint (Section 2).  
* **Service implementations** that mirror the Java business logic, flagged by complexity (Section 5).  
* A **migration checklist** of manual tasks (Section 6).  
* A **test suite** that guarantees functional parity and contract compatibility (Section 7).  

Following this plan will let the team move incrementally: start with the thin client wrappers (RemoteWorkflowEngine, RemoteBlobStorage), then port validation services, and finally rewrite the integration‑flow‑heavy mail‑worker subsystem.  Each step can be validated against the existing Java service through contract tests, ensuring a safe cut‑over.

</details>

## 📝 All TODO Comments

<details>
<summary>Show all 67 TODOs</summary>

- `remote_workflow_engine.go:11`: // TODO manual migration: translate the Java implementation logic.
- `mail_receiver_manager.go:21`: // TODO manual migration: implement worker start logic
- `mail_receiver_manager.go:30`: // TODO manual migration: implement stop logic
- `mail_receiver_manager.go:35`: // TODO manual migration: implement consumer closing logic
- `mail_receiver_manager.go:40`: // TODO manual migration: implement stop process logic
- `mail_receiver_manager.go:46`: // TODO manual migration: return set of healthy consumer UUIDs
- `mail_receiver_manager.go:51`: // TODO manual migration: implement secret application logic
- `script_executor_service.go:18`: // TODO manual migration: implement placeholder resolution logic
- `script_executor_service.go:23`: // TODO manual migration: implement script execution logic
- `script_executor_service.go:29`: // TODO manual migration: implement context compilation
- `script_executor_service.go:35`: // TODO manual migration: implement check logic
- `script_executor_service.go:40`: // TODO manual migration: implement injection logic
- `script_executor_service.go:46`: // TODO manual migration: implement filter logic
- `validation_service.go:19`: // TODO manual migration: implement validation logic
- `validation_service.go:25`: // TODO manual migration: implement parsing logic
- `validation_service.go:31`: // TODO manual migration: implement generic validation logic
- `validation_service.go:36`: // TODO manual migration: implement compatibility validation
- `starter_script_validation_service.go:21`: // TODO manual migration: implement conversion logic
- `starter_script_validation_service.go:27`: // TODO manual migration: implement parsing logic
- `starter_script_validation_service.go:33`: // TODO manual migration: implement example creation
- `starter_script_validation_service.go:39`: // TODO manual migration: implement validation logic
- `starter_script_validation_service.go:44`: // TODO manual migration: implement JSON schema validation
- `starter_script_validation_service.go:49`: // TODO manual migration: implement transformation logic
- `starter_script_validation_service.go:54`: // TODO manual migration: implement script context compilation
- `variable_validator.go:12`: // TODO manual migration: implement variable validation logic
- `remote_blob_storage.go:15`: // TODO manual migration: implement blob save logic
- `remote_blob_storage.go:21`: // TODO manual migration: implement find logic returning InputStream equivalent
- `remote_blob_storage.go:26`: // TODO manual migration: implement JSON retrieval logic
- `remote_blob_storage.go:31`: // TODO manual migration: implement deserialization logic
- `handlers.go:12`: // TODO: implement business logic
- `handlers.go:20`: // TODO: implement business logic
- `handlers.go:29`: // TODO: implement business logic
- `stubs_generated.go:5`: // TODO: Replace with real implementations.
- `stubs_generated.go:7`: // TODO: Define ApplyPlaneVaultSecrets properly
- `stubs_generated.go:10`: // TODO: Define CloseBrokenConsumers properly
- `stubs_generated.go:13`: // TODO: Define CompileExecutionContext properly
- `stubs_generated.go:16`: // TODO: Define CompileScriptContext properly
- `stubs_generated.go:19`: // TODO: Define CreateExampleForSchema properly
- `stubs_generated.go:22`: // TODO: Define DeserializeBlob properly
- `stubs_generated.go:25`: // TODO: Define ErrorDecoder properly
- `stubs_generated.go:28`: // TODO: Define ExecuteScript properly
- `stubs_generated.go:31`: // TODO: Define Filter properly
- `stubs_generated.go:34`: // TODO: Define Find properly
- `stubs_generated.go:37`: // TODO: Define FindJson properly
- `stubs_generated.go:40`: // TODO: Define GetHealthyConsumers properly
- `stubs_generated.go:43`: // TODO: Define GetWorkerCount properly
- `stubs_generated.go:46`: // TODO: Define HttpStatus properly
- `stubs_generated.go:49`: // TODO: Define InjectActivityArgsToContext properly
- `stubs_generated.go:52`: // TODO: Define IntegrationFlow properly
- `stubs_generated.go:55`: // TODO: Define IntegrationFlowContext properly
- `stubs_generated.go:58`: // TODO: Define IsExecutable properly
- `stubs_generated.go:61`: // TODO: Define Parse properly
- `stubs_generated.go:64`: // TODO: Define ResolvePlaceholders properly
- `stubs_generated.go:67`: // TODO: Define Save properly
- `stubs_generated.go:70`: // TODO: Define ScriptExecutorClient properly
- `stubs_generated.go:73`: // TODO: Define StartFlow properly
- `stubs_generated.go:76`: // TODO: Define StartWorker properly
- `stubs_generated.go:79`: // TODO: Define StopProcessByWorkerId properly
- `stubs_generated.go:82`: // TODO: Define StopStolenLocalWorkers properly
- `stubs_generated.go:85`: // TODO: Define ToVariablesJsonSchema properly
- `stubs_generated.go:88`: // TODO: Define TransformMailOutput properly
- `stubs_generated.go:91`: // TODO: Define Valid properly
- `stubs_generated.go:94`: // TODO: Define Validate properly
- `stubs_generated.go:97`: // TODO: Define ValidateJson properly
- `stubs_generated.go:100`: // TODO: Define ValidateOutputTemplateValueReplacement properly
- `stubs_generated.go:103`: // TODO: Define ValidateStarterCompatibility properly
- `stubs_generated.go:106`: // TODO: Define ValidateVariables properly

</details>

## 🔧 Linter Auto-fixes

`golangci-lint` автоматически исправил 22 проблем:

- models_1.go: fixed syntax errors
- models_2.go: fixed syntax errors
- models_3.go: fixed syntax errors
- models_4.go: fixed syntax errors
- models_5.go: fixed syntax errors
- models_6.go: fixed syntax errors
- remote_workflow_engine.go: fixed syntax errors
- mail_receiver_manager.go: fixed syntax errors
- script_executor_service.go: fixed syntax errors
- validation_service.go: fixed syntax errors
- starter_script_validation_service.go: fixed syntax errors
- variable_validator.go: fixed syntax errors
- remote_blob_storage.go: fixed syntax errors
- router.go: fixed syntax errors
- main.go: fixed syntax errors

... и ещё 7 исправлений
