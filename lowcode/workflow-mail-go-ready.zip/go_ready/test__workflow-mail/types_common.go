package main


// Base type aliases
type JsonNode = map[string]interface{}
// Auto-generated missing types
type WorkflowRef = string
type WorkflowStartConfig = map[string]interface{}
type BusinessKey = string
type TaskTimeout = int64
type RunTimeout = int64
type ExecutionTimeout = int64
type Id = string
