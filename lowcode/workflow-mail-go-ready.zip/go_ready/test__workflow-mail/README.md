# ru-mts-workflowmail

Migrated from Java Spring Boot to Go.

## Quick Start

```bash
go mod tidy
go build -o main .
./main
```

Server starts on port 8080. Health check: http://localhost:8080/health

## Docker

```bash
docker build -t ru-mts-workflowmail .
docker run -p 8080:8080 ru-mts-workflowmail
```

## Reports

- [report.md](report.md) — Human-readable report
- [report.json](report.json) — Machine-readable report
- `BUILD_REPORT.md` — Detailed build analysis

## Project Structure

```
├── main.go              # Entry point
├── router.go            # Gin routes & middleware
├── handlers.go          # HTTP handlers (add logic here)
├── models_*.go          # Data models (structs)
├── *_service.go         # Business logic
├── stubs_generated.go   # Empty stubs (replace these)
├── types_common.go      # Type aliases
├── Dockerfile           # Docker build
├── report.md            # Migration report
└── report.json          # Machine-readable report
```
