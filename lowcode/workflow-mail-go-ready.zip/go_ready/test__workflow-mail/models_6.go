package main

type DynamicMailListener struct {
    WorkflowEngine                interface{} `json:"workflowEngine"`
    BlobStorage                   interface{} `json:"blobStorage"`
    Props                         interface{} `json:"props"`
    StarterScriptValidationService interface{} `json:"starterScriptValidationService"`
    IMAPS                         string      `json:"IMAPS"`
    IMAP                          string      `json:"IMAP"`
}  

type MailConnection struct {
    Protocol string    `json:"protocol"`
    Host     string    `json:"host"`
    Port     int       `json:"port"`
    MailAuth *MailAuth `json:"mailAuth"`
}  

type MailAuth struct {
    Username    string          `json:"username"`
    Password    string          `json:"password"`
    Certificate *MailCertificate `json:"certificate"`
}  

type MailCertificate struct {
    TrustStoreType        string `json:"trustStoreType"`
    TrustStoreCertificates string `json:"trustStoreCertificates"`
}  

type Ref struct {
    ID       string `json:"id"`
    Name     string `json:"name"`
    Version  int    `json:"version"`
    TenantID string `json:"tenantId"`
}  

type ConsumerError struct {
    WorkerID string `json:"workerId"`
    Error    error  `json:"error"`
}  

type MailConsumerForInternal struct {
    OutputTemplate interface{} `json:"outputTemplate"`
} 

type CompatibilityStarter struct {
    Consumer                 *MailConsumerForInternal `json:"consumer"`
    WorkflowInputValidateSchema interface{}               `json:"workflowInputValidateSchema"`
}  

type MailPollConfig struct {
    PollDelaySeconds int64 `json:"pollDelaySeconds"`
    MaxFetchSize     int   `json:"maxFetchSize"`
} 

type ConstraintViolationException struct {
    Errors []ErrorDescription `json:"errors"`
}  

type EntityNotFoundException struct {
    SerialVersionUID int64 `json:"serialVersionUID"`
}  

type StarterErrorContext struct {
    ID   string `json:"id"`
    Type string `json:"type"`
    Name string `json:"name"`
}  

type ScriptErrorContext struct {
    VariableContext   interface{}   `json:"variableContext"`
    WF                interface{}   `json:"wf"`
    RejectedScript    string        `json:"rejectedScript"`
    SystemMessage     string        `json:"systemMessage"`
    UnknownVariables  []string      `json:"unknownVariables"`
}  

type WorkflowEngineException struct {
    Descriptions []ErrorDescription `json:"descriptions"`
}  

type InfinityCyclesContext struct {
    InfinityCycles [][]string `json:"infinityCycles"`
} 

type ErrorContext struct {
    RejectedValue interface{} `json:"rejectedValue"`
    SystemMessage string      `json:"systemMessage"`
} 
type MailConnectionException struct {}

type ErrorMessagePouch struct {
    SystemMessage   string        `json:"systemMessage"`
    MessageAargs    []interface{} `json:"messageAargs"`
    AdviceMessageArgs []interface{} `json:"adviceMessageArgs"`
} 

type ErrorLocation struct {
    FieldPath      string   `json:"fieldPath"`
    ActivityID     string   `json:"activityId"`
    ExecutionPath  []string `json:"executionPath"`
    NextTransition string   `json:"nextTransition"`
}  