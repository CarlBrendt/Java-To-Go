package main

import (
	"io"
)

func NewRemoteBlobStorage(client BlobStorageServiceClient, om ObjectMapper) *RemoteBlobStorage {
    return &RemoteBlobStorage{
        BlobServiceClient: client,
        OM:                om,
    }
}

// Save mirrors RemoteBlobStorage.save()
func (r *RemoteBlobStorage) Save(data []byte) (BlobRef, error) {
    // TODO manual migration: implement blob save logic
    var ref BlobRef
    return ref, nil}

// Find mirrors RemoteBlobStorage.find()
func (r *RemoteBlobStorage) Find(id string) (io.ReadCloser, error) {
    // TODO manual migration: implement find logic returning InputStream equivalent
    return nil, nil
}

// FindJson mirrors RemoteBlobStorage.findJson()
func (r *RemoteBlobStorage) FindJson(id string) (*JsonNode, error) {
    // TODO manual migration: implement JSON retrieval logic
    return nil, nil
}
// DeserializeBlob mirrors RemoteBlobStorage.deserializeBlod()
func (r *RemoteBlobStorage) DeserializeBlob(data []byte) (JsonNode, error) {
    // TODO manual migration: implement deserialization logic
    var node JsonNode
    return node, nil
}
