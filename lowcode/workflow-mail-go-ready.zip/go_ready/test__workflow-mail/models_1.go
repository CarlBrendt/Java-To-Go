package main

import (
	"encoding/json"
	"time"
)

type WorkflowEngineClient interface{}

type DtoMapper interface{}

type ObjectMapper interface{}

type ErrorDescription struct{}

type ErrorMessageArgs struct{}

type StarterScriptValidationService interface{}

type ErrorCompiler interface{}

type ScriptExecutorService interface{}

type ScriptExecutionContext struct{}

type Validation struct{}

type ValidationHelper struct {
    OM ObjectMapper `json:"om,omitempty"`
}  // ← ДОБАВИТЬ эту скобку

type Constraint struct{}

type Errors2 struct {  // ← УБРАТЬ звездочку *
    Code                string `json:"code,omitempty"`
    Level               string `json:"level,omitempty"`
    ErrorMessageAlias   string `json:"errorMessageAlias,omitempty"`
    SolvingMessageAlias string `json:"solvingMessageAlias,omitempty"`
}

type JsonParseResult struct {
    Json   json.RawMessage   `json:"json,omitempty"`
    Errors []ErrorDescription `json:"errors,omitempty"`
}

type ValidateDecision struct {
    Error              *Errors2            `json:"error,omitempty"`
    Args               ErrorMessageArgs   `json:"args,omitempty"`
    ErrorDescriptions  []ErrorDescription `json:"errorDescriptions,omitempty"`
    Cause              *ValidateDecision  `json:"cause,omitempty"`
}

type ValidationResult struct {
    Json   json.RawMessage   `json:"json,omitempty"`
    Errors []ErrorDescription `json:"errors,omitempty"`
}

type Context struct {
    ScriptValidationService   StarterScriptValidationService `json:"scriptValidationService,omitempty"`
    Compiler                  ErrorCompiler                 `json:"compiler,omitempty"`
    ScriptExecutorService     ScriptExecutorService         `json:"scriptExecutorService,omitempty"`
    MailConsumerScriptContext ScriptExecutionContext        `json:"mailConsumerScriptContext,omitempty"`
}

type RemoteWorkflowEngine struct {
    Client    WorkflowEngineClient `json:"client,omitempty"`
    DtoMapper DtoMapper           `json:"dtoMapper,omitempty"`
}

type WorkflowEngine struct {}

type ReqRef struct {
    ID       string `json:"id,omitempty"`
    Name     string `json:"name,omitempty"`
    TenantId string `json:"tenantId,omitempty"`
}

type ReqWorkflowStartConfig struct {
    BusinessKey      string          `json:"businessKey,omitempty"`
    Variables        json.RawMessage `json:"variables,omitempty"`
    TaskTimeout      time.Duration   `json:"taskTimeout,omitempty"`
    RunTimeout       time.Duration   `json:"runTimeout,omitempty"`
    ExecutionTimeout time.Duration   `json:"executionTimeout,omitempty"`
}

type ReqStartWorkflow struct {
    WorkflowRef        ReqRef                `json:"workflowRef,omitempty"`
    WorkflowStartConfig ReqWorkflowStartConfig `json:"workflowStartConfig,omitempty"`
}

type ReqCompatibilityStarterSchema struct {
    OutputTemplate              string `json:"outputTemplate,omitempty"`
    WorkflowInputValidateSchema string `json:"workflowInputValidateSchema,omitempty"`
}

type MailFilterSchema struct {
    Senders          string `json:"senders,omitempty"`
    Subjects         string `json:"subjects,omitempty"`
    StartMailDateTime string `json:"startMailDateTime,omitempty"`
}

type MailStarterSchema struct {
    Description                 string `json:"description,omitempty"`
    TenantId                    string `json:"tenantId,omitempty"`
    Connection                  string `json:"connection,omitempty"`
    MailFilter                  string `json:"mailFilter,omitempty"`
    OutputTemplate              string `json:"outputTemplate,omitempty"`
    WorkflowDefinitionToStartId string `json:"workflowDefinitionToStartId,omitempty"`
    WorkflowInputValidateSchema string `json:"workflowInputValidateSchema,omitempty"`
}

type MailStarterConsumerSchema struct {
    Connection    string `json:"connection,omitempty"`
    MailFilter    string `json:"mailFilter,omitempty"`
    OutputTemplate string `json:"outputTemplate,omitempty"`
}

type StarterSearchingSchema struct {
    Limit                        string `json:"limit,omitempty"`
    Offset                       string `json:"offset,omitempty"`
    Name                         string `json:"name,omitempty"`
    TenantId                     string `json:"tenantId,omitempty"`
    WorkflowDefinitionToStartIds string `json:"workflowDefinitionToStartIds,omitempty"`
    DesiredStatuses              string `json:"desiredStatuses,omitempty"`
    ActualStatuses               string `json:"actualStatuses,omitempty"`
    Sorting                      string `json:"sorting,omitempty"`
    SortingName                  string `json:"sortingName,omitempty"`
    SortingDirection             string `json:"sortingDirection,omitempty"`
}

type MailAuthSchema struct {
    Username string `json:"username,omitempty"`
    Password string `json:"password,omitempty"`
}

type MailConnectionSchema struct {
    Protocol string `json:"protocol,omitempty"`
    Host     string `json:"host,omitempty"`
    Port     string `json:"port,omitempty"`
    MailAuth string `json:"mailAuth,omitempty"`
}

type DateHelper struct {
    DefaultDateTimePattern        string `json:"defaultDateTimePattern,omitempty"`
    ZonedDateTimePattern          string `json:"zonedDateTimePattern,omitempty"`
    ISOOffssetDateTimePattern     string `json:"isoOffssetDateTimePattern,omitempty"`
    ISOOffsetDateTimeFormatter    string `json:"isoOffsetDateTimeFormatter,omitempty"`
    QueueDateTimeFormatter        string `json:"queueDateTimeFormatter,omitempty"`
    DefaultClientZoneOffset       string `json:"defaultClientZoneOffset,omitempty"`
}

type ObservationConfiguration struct {
    EngineConfig EngineConfigurationProperties `json:"engineConfig,omitempty"`
}

type EWSConfig struct {}

type RedirectionUrlCallback struct {}

type LocalizationConfiguration struct {}

type SecurityConfiguration struct {
    EngineConfig EngineConfigurationProperties `json:"engineConfig,omitempty"`
}

type SwaggerConfig struct {}

type EngineConfigurationProperties struct {
    WorkflowExecutionConfig                WorkflowExecutionDefaultConfig `json:"workflowExecutionConfig,omitempty"`
    WorkflowDslQueueName                   string                        `json:"workflowDslQueueName,omitempty"`
    ActivityFindWorkflowDefinitionQueueName string                        `json:"activityFindWorkflowDefinitionQueueName,omitempty"`
    ActivityDbCallQueueName                string                        `json:"activityDbCallQueueName,omitempty"`
    ActivityRestCallQueueName              string                        `json:"activityRestCallQueueName,omitempty"`
    ActivitySendToKafkaQueueName           string                        `json:"activitySendToKafkaQueueName,omitempty"`
    ActivitySendToRabbitmqQueueName        string                        `json:"activitySendToRabbitmqQueueName,omitempty"`
    ActivitySendToSapQueueName             string                        `json:"activitySendToSapQueueName,omitempty"`
    ActivityXsltTransformQueueName         string                        `json:"activityXsltTransformQueueName,omitempty"`
    WorkflowWikiErrorsUrlPattern           string                        `json:"workflowWikiErrorsUrlPattern,omitempty"`
    SecurityEnabled                       bool                          `json:"securityEnabled,omitempty"`
    OpentelemetryTraceExporterEndpoint    string                        `json:"opentelemetryTraceExporterEndpoint,omitempty"`
    OpentelemetryServiceName              string                        `json:"opentelemetryServiceName,omitempty"`
    OpentelemetryServiceVersion           string                        `json:"opentelemetryServiceVersion,omitempty"`
    MailWorkerLimitCount                  int                           `json:"mailWorkerLimitCount,omitempty"`
    MaxVariableSizeBytes                  int64                         `json:"maxVariableSizeBytes,omitempty"`
    PollMessageDelaySeconds               int64                         `json:"pollMessageDelaySeconds,omitempty"`
    MaxMessageFetchSize                   int                           `json:"maxMessageFetchSize,omitempty"`
}

type WorkflowExecutionDefaultConfig struct {
    DefaultExecutionTimeout       time.Duration `json:"defaultExecutionTimeout,omitempty"`
    DefaultExecutionTimeoutSeconds int          `json:"defaultExecutionTimeoutSeconds,omitempty"`
}

type CronValidator struct {}