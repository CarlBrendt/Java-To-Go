package main


type Const struct {
    NewLine          string `json:"newLine"`
    DefaultTenantId  string `json:"defaultTenantId"`}

type IntegrationDirection struct {
    Input          string   `json:"input"`
    Output         string   `json:"output"`
    PossibleValues []string `json:"possibleValues"`}

type StarterJsonSchema struct {
    MailJson string `json:"mailJson"`}

type SortingDirection struct {
    Asc            string   `json:"asc"`
    Desc           string   `json:"desc"`
    PossibleValues []string `json:"possibleValues"`}

type StarterSortingFields struct {
    CreateTime    string   `json:"createTime"`
    DesiredStatus string   `json:"desiredStatus"`
    PossibleValues []string `json:"possibleValues"`}

type MailWorkerStatus struct {
    ScheduledToStart   string   `json:"scheduledToStart"`
    Started            string   `json:"started"`
    Error              string   `json:"error"`
    ScheduledToRestart string   `json:"scheduledToRestart"`
    ScheduledToTerminate string `json:"scheduledToTerminate"`
    Terminated         string   `json:"terminated"`
    ScheduledToDelete  string   `json:"scheduledToDelete"`
    Deleted            string   `json:"deleted"`
    PossibleValues     []string `json:"possibleValues"`}

type MailConnectionProtocol struct {
    Imap           string   `json:"imap"`
    Ews            string   `json:"ews"`
    PossibleValues []string `json:"possibleValues"`}

type MailStarterStatus struct {
    Started   string   `json:"started"`
    Terminated string  `json:"terminated"`
    Error     string   `json:"error"`
    Unknown   string   `json:"unknown"`
    Deleted   string   `json:"deleted"`
    PossibleValues []string `json:"possibleValues"`}

type IntegrationKind struct {
    Sap            string   `json:"sap"`
    Database       string   `json:"database"`
    Rest           string   `json:"rest"`
    Rabbit         string   `json:"rabbit"`
    Kafka          string   `json:"kafka"`
    PossibleValues []string `json:"possibleValues"`}

type ExecutionType struct {
    Sequential string `json:"sequential"`}

type ErrorLevel struct {
    Critical string `json:"critical"`
    Warning  string `json:"warning"`}

type ScriptType struct {
    Jp            string   `json:"jp"`
    Spel          string   `json:"spel"`
    PossibleValues []string `json:"possibleValues"`}

type RestCallMethod struct {
    Get     string   `json:"get"`
    Post    string   `json:"post"`
    Patch   string   `json:"patch"`
    Put     string   `json:"put"`
    Head    string   `json:"head"`
    Delete  string   `json:"delete"`
    Options string   `json:"options"`
    Trace   string   `json:"trace"`
    PossibleValues []string `json:"possibleValues"`}

type AuthType struct {
    Oauth2  string   `json:"oauth2"`
    Basic   string   `json:"basic"`
    PossibleValues []string `json:"possibleValues"`}

type URLProtocol struct {
    Http    string   `json:"http"`
    Https   string   `json:"https"`
    PossibleValues []string `json:"possibleValues"`}

type GrantType struct {
    ClientCredentials string   `json:"clientCredentials"`
    PossibleValues    []string `json:"possibleValues"`}

type SslTrustStoreType struct {
    Pem            string   `json:"pem"`
    PossibleValues []string `json:"possibleValues"`}

type MailAuthType struct {
    Sasl           string   `json:"sasl"`
    Tls            string   `json:"tls"`
    PossibleValues []string `json:"possibleValues"`}

type SaslProtocol struct {
    SaslSsl        string   `json:"saslSsl"`
    SaslPlaintext  string   `json:"saslPlaintext"`
    PossibleValues []string `json:"possibleValues"`}

type SaslMechanism struct {
    ScramSha512   string   `json:"scramSha512"`
    Oauthbearer   string   `json:"oauthbearer"`
    PossibleValues []string `json:"possibleValues"`}

type WorkflowType struct {
    SendToKafka string `json:"sendToKafka"`}

type StarterType struct {
    KafkaConsumer   string   `json:"kafkaConsumer"`
    RabbitmqConsumer string  `json:"rabbitmqConsumer"`
    SapInbound      string   `json:"sapInbound"`
    Scheduler       string   `json:"scheduler"`
    RestCall        string   `json:"restCall"`
    MailConsumer    string   `json:"mailConsumer"`
    PossibleValues  []string `json:"possibleValues"`}

type ApplicationInstance struct {
    ID    *ApplicationInstance `json:"id"`
    Value string               `json:"value"`}

type WikiErrorPageProvider struct {
    Props EngineConfigurationProperties `json:"props"`}

type ScriptExecutorServiceImpl struct {
    ScriptExecutorClient ScriptExecutorClient `json:"scriptExecutorClient"`
    Mapper               DtoMapper           `json:"mapper"`
    OM                   ObjectMapper        `json:"OM"`}

type MailReceiverManager struct {
    AllWorkers              map[string]MailListenerContainerWrapper `json:"allWorkers"`
    Mapper                  DtoMapper                               `json:"mapper"`
    ListenerConfig          DynamicMailListener                     `json:"listenerConfig"`
    VaultPropertiesResolver FetchedVaultPropertiesResolver          `json:"vaultPropertiesResolver"`
    FlowContext             IntegrationFlowContext                  `json:"flowContext"`
}

type InputValidationContext struct {
    InputValidateSchema JsonNode            `json:"inputValidateSchema"`
    ValidationTarget    JsonNode            `json:"validationTarget"`
    PropertyViolations  []PropertyViolation `json:"propertyViolations"`}

type ReqIsExecutable struct {
    Script string `json:"script"`}

type ResIsExecutable struct {
    Result bool `json:"result"`}

type ReqResolvePlaceholdersExecutionContext struct {
    ScriptContext ReqScriptExecutionContext `json:"scriptContext"`
    Node         JsonNode                 `json:"node"`}
