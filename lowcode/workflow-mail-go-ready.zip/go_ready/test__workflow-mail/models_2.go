package main

import (
	"encoding/json"
	"time"
)

type MapSchema struct {
    ValueField BaseSchema               `json:"valueField"`
    Nested     map[string]BaseSchema    `json:"nested"`
}  

type InstantiationHelper struct {}

type BooleanSchema struct {}

type ArraySchema struct {
    ValueField BaseSchema               `json:"valueField"`
    Nested     map[string]BaseSchema    `json:"nested"`
}  

type StringSchema struct {}

type NumberSchema struct {}

type ObjectSchema struct {
    Nested    map[string]BaseSchema `json:"nested"`
    AfterFiled BaseSchema           `json:"afterFiled"`
} 

type BaseSchema struct {
    Violations []ConstraintViolation `json:"violations"`
    Path       string                `json:"path"`
    Constraints []Constraint         `json:"constraints"`
}  

type ConstraintViolation struct {
    Error          Errors2               `json:"error"`
    Path           string                `json:"path"`
    RejectedValue  json.RawMessage       `json:"rejectedValue"`
    MessageArgs    ErrorMessageArgs      `json:"messageArgs"`
    CompleteErrors []ErrorDescription    `json:"completeErrors"`
    Cause          *ConstraintViolation  `json:"cause"`
}  

type ScriptExecutionErrorDecoder struct {
    ErrorDecoder ErrorDecoder   `json:"errorDecoder"`
    OM           interface{}   `json:"OM"`
} 

type ScriptExecutionErrors struct {
    ErrorDescriptions []ErrorDescription `json:"errorDescriptions"`
}  

type ErrorHelper struct {}

type ClientErrorDescription struct {
    Error                Errors2                `json:"error"`
    MessageArgs          []interface{}          `json:"messageArgs"`
    AdviceMessageArgs    []interface{}          `json:"adviceMessageArgs"`
    SystemMessage        string                 `json:"systemMessage"`
    Location             ErrorLocation          `json:"location"`
    Context              ErrorContext           `json:"context"`
    ScriptContext        ScriptErrorContext     `json:"scriptContext"`
    InputValidationContext InputValidationContext `json:"inputValidationContext"`
}  // ← ДОБАВИТЬ

type ResolvePlaceholdersExecutionResult struct {
    ResultNode json.RawMessage `json:"resultNode"`
}  // ← ДОБАВИТЬ

type ClientError struct {
    Status               HttpStatus               `json:"status"`
    Errors               []ClientErrorDescription `json:"errors"`
    CompiledErrors       []ErrorDescription       `json:"compiledErrors"`
    ConstraintViolation  ConstraintViolation      `json:"constraintViolation"`
}  // ← ДОБАВИТЬ (было пропущено)

type ScriptWorkflowView struct {
    BusinessKey   string                     `json:"businessKey"`
    Secrets       map[string]string          `json:"secrets"`
    InitVariables map[string]json.RawMessage `json:"initVariables"`
}  // ← ДОБАВИТЬ

type ResolvePlaceholdersExecutionContext struct {
    ScriptContext ScriptExecutionContext `json:"scriptContext"`
    Node          json.RawMessage        `json:"node"`
}  // ← ДОБАВИТЬ

type FeignMdcRequestInterceptor struct {}

type MailValidationApi struct {}

type Worker struct {
    ID               string `json:"id"`
    CreateTime       time.Time  `json:"createTime"`
    ChangeTime       time.Time  `json:"changeTime"`
    ExecutorID       string `json:"executorId"`
    LockedUntilTime  time.Time  `json:"lockedUntilTime"`
    RetryCount       int        `json:"retryCount"`
    Status           string     `json:"status"`
    ErrorMessage     string     `json:"errorMessage"`
    ErrorStackTrace  string     `json:"errorStackTrace"`
    Starter          Starter    `json:"starter"`
}  

type ReqWorkflowForStarter struct {
    StartWorkflow  ReqStartWorkflow `json:"startWorkflow"`
    WorkerIdentity WorkerIdentity   `json:"workerIdentity"`
}  

type WorkerLocker struct {
    ExecutorID string `json:"executorId" validate:"required"`
    Type       string    `json:"type" validate:"required"`
    Statuses   []string  `json:"statuses"`
}  

type ReqStopStarter struct {
    Name       string    `json:"name" validate:"required"`
    TenantId   string    `json:"tenantId"`
    WorkflowId string `json:"workflowId" validate:"required"`
}  

type WorkerExtend struct {
    WorkerIds  []string `json:"workerIds"`
    ExecutorID string   `json:"executorId"`
} 

type ResIdHolder struct {
    ID string `json:"id"`
}  

type ReqMailConsumerForInternal struct {
    OutputTemplate json.RawMessage `json:"outputTemplate"`
} 

type ResCommonErrorWithDescriptions struct {
    Timestamp         time.Time               `json:"timestamp"`
    Status            int                     `json:"status"`
    Error             string                  `json:"error"`
    Path              string                  `json:"path"`
    ErrorDescriptions []ResErrorDescription   `json:"errorDescriptions"`
} 

type ResCount struct {
    Count int64 `json:"count"`
} 